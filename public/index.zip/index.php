<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// Baris untuk Cek Maintenance Mode
if (file_exists($maintenance = __DIR__.'/storage/framework/maintenance.php')) {
    require $maintenance;
}

// BARIS 14: Ubah jadi seperti ini (Hapus ../ )
require __DIR__.'/vendor/autoload.php';

// BARIS 17: Ubah jadi seperti ini (Hapus ../ )
/** @var Application $app */
$app = require_once __DIR__.'/bootstrap/app.php';

$app->handleRequest(Request::capture());